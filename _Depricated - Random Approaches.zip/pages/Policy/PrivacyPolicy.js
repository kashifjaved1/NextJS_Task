import axios from "axios";
import DisplayPolicyData from "../../components/DisplayPolicyData";

export default function PrivacyPolicy({data}) {
    return DisplayPolicyData(data)
}

export async function getServerSideProps() {
    const privacyPolicy = await axios.get("https://test-web-link.themarche.ca/api/PoliciesManagement/PrivacyPolicy");
    return {
        props: {data: privacyPolicy.data},
    };
}
