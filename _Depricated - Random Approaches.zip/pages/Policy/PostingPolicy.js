import axios from "axios";
import DisplayPolicyData from "../../components/DisplayPolicyData";

export default function PostingPolicy({data}) {
    return DisplayPolicyData(data)
}

export async function getServerSideProps() {
    const postingPolicy = await axios.get("https://test-web-link.themarche.ca/api/PoliciesManagement/PostingPolicy");
    return {
        props: {data: postingPolicy.data},
    };
}