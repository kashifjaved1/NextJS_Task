import axios from "axios";
import DisplayPolicyData from "../../components/DisplayPolicyData";

export default function CookiePolicy({data}) {
    return DisplayPolicyData(data)
}

export async function getServerSideProps() {
    const cookiePolicy = await axios.get("https://test-web-link.themarche.ca/api/PoliciesManagement/CookiePolicy");
    return {
        props: {data: cookiePolicy.data},
    };
}