import axios from "axios";
import DisplayPolicyData from "../../components/DisplayPolicyData";

export default function TermsOfUse({data}) {
    return DisplayPolicyData(data)
}

export async function getServerSideProps() {
    const termsOfUse = await axios.get("https://test-web-link.themarche.ca/api/PoliciesManagement/TermsOfUse");
    return {
        props: {data: termsOfUse.data},
    };
}
