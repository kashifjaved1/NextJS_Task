import {useEffect} from "react";

export default function index() {
    CheckForFirstTimeLoad()
    return <></>
}

const CheckForFirstTimeLoad = () => {
    useEffect(() => {
        if(!localStorage.getItem("firstTimeLoadingToken")){
            localStorage.setItem("firstTimeLoadingToken", "28dee7e851587c95ed33c2de7c1e8b26")
            location.href = "/Policy/TermsOfUse"
        }
        location.href = "/Policy/PrivacyPolicy"
    }, [])
}

