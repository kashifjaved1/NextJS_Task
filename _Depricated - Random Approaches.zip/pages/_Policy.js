import {Menu} from 'antd';
import {useEffect, useState} from "react";
import styles from '../styles/Policy.module.css'
import axios from "axios";
import {useRouter} from "next/router";
const {SubMenu} = Menu;
//let firstTime = false;

export default function Index({TermsOfUse, PrivacyPolicy, PostingPolicy, CookiePolicy}) {
    const router = useRouter()
    /*useEffect(() => {
        if (localStorage.getItem("firstTimeLoadToken") == null){
            localStorage.setItem("firstTimeLoadToken", "344d8e5f6740a1aca5e73b5e7aae3bec")
            firstTime = true;
        }
    }, [])*/

    const handleClick = e => {
        console.log('click ', e);
    };

    return (
        <div className={styles.policyPage}>
            <div>
                <Menu
                    onClick={handleClick}
                    style={{width: 256}}
                    defaultSelectedKeys={['1']}
                    defaultOpenKeys={['sub1']}
                    mode="inline"
                >
                    <SubMenu key="sub1" title="General Policy" className={styles.mainMenuColor}>
                        <Menu.Item key="1" onClick={() => router.push('/Policy')}>Term of Use</Menu.Item>
                        <Menu.Item key="2">Privacy Index 1</Menu.Item>
                        <Menu.Item key="3">Posting Index 1</Menu.Item>
                        <Menu.Item key="4">Cookie Index 1</Menu.Item>
                    </SubMenu>
                </Menu>
            </div>
            <div dangerouslySetInnerHTML={{__html: TermsOfUse}} className={styles.policyDetail} />
            <div dangerouslySetInnerHTML={{__html: PrivacyPolicy}} className={styles.policyDetail} />
            <div dangerouslySetInnerHTML={{__html: PostingPolicy}} className={styles.policyDetail} />
            <div dangerouslySetInnerHTML={{__html: CookiePolicy}} className={styles.policyDetail} />
        </div>
    );
}

export async function getServerSideProps() {
    const [termsOfUse, privacyPolicy, postingPolicy, cookiePolicy] = await Promise.all([
        axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/TermsOfUse`),
        axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/PrivacyPolicy1`),
        axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/PostingPolicy1`),
        axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/CookiePolicy1`)
    ])

    /*const termsOfUse = await axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/TermsOfUse`)*/
    /*const privacyPolicy = await axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/PrivacyPolicy1`)*/
    /*const postingPolicy = await axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/PostingPolicy1`)*/
    /*const cookiePolicy = await axios.get(`https://test-web-link.themarche.ca/api/PoliciesManagement/CookiePolicy1`)*/

    const [TermsOfUse, PrivacyPolicy, PostingPolicy, CookiePolicy] = await Promise.all([
        termsOfUse.data,
        privacyPolicy.data,
        postingPolicy.data,
        cookiePolicy.data
    ])

    return {
        props: {
            TermsOfUse, PrivacyPolicy, PostingPolicy, CookiePolicy
        }
    };
}


