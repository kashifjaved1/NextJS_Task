import PolicyLayout from "../layouts/PolicyLayout";
import styles from "../styles/Policy.module.css";

export default function DisplayPolicyData(data) {
    return (
        //<div className={styles.policyDetail} dangerouslySetInnerHTML={{__html: data}} />
        <PolicyLayout>
            <div className={styles.policyDetail} dangerouslySetInnerHTML={{__html: data}} />
        </PolicyLayout>
    )
}