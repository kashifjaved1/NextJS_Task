export const PolicyList = {
    TERMS_OF_USE: "Terms Of Use",
    PRIVACY_POLICY: "Privacy Policy",
    POSTING_POLICY: "Posting Policy",
    COOKIE_POLICY: "Cookie Policy",
};
