import Link from 'next/link'
import styles from "../styles/Policy.module.css";
import {Menu} from "antd";

const {SubMenu} = Menu;

export default function PolicyMenu() {
    const handleClick = e => {
        console.log('click ', e);
    };

    return (
        <>
            <Menu
                onClick={handleClick}
                style={{width: 256}}
                defaultSelectedKeys={['1']}
                defaultOpenKeys={['sub1']}
                mode="inline"
            >
                <SubMenu key="sub1" title="General Policy" className={styles.mainMenuColor}>
                    <Menu.Item key="1"><Link href="/Policy/TermsOfUse">Term of Use</Link></Menu.Item>
                    <Menu.Item key="2"><Link href="/Policy/PrivacyPolicy">Privacy Policy 1</Link></Menu.Item>
                    <Menu.Item key="3"><Link href="/Policy/PostingPolicy">Posting Policy 1</Link></Menu.Item>
                    <Menu.Item key="4"><Link href="/Policy/CookiePolicy">Cookie Policy 1</Link></Menu.Item>
                </SubMenu>
            </Menu>
        </>
    );
}