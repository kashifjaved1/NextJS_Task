export default function Footer()
{
    return (
        <div className="footer">
            <p>© themarche.ca 2021, All Rights Reserved.</p>
        </div>
    );
}