import PolicyMenu from "../components/PolicyMenu";
import styles from '../styles/Policy.module.css'

export default function PolicyLayout({children}) {
    return (
        <div className={styles.policyPage}>
            <PolicyMenu />
            {children}
        </div>
    )
}